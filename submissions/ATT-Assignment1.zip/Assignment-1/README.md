#Course Project Assignment #1 - Front End Requirements
###Taylor Smith
###Alexandar Mihaylov
###Talha Zia

**Part1:** Report.pdf - page 2
**Part2:** Assignment-1/tests
**Part3:** Report.pdf - page 17





























