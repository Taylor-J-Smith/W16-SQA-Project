#ifndef CREATEHANDLER_H_
#define CREATEHANDLER_H_

#include <string>
#include "TransactionHandler.h"
#include "AccountConstants.h"
#include "SessionStatus.h"
#include "CommandValidator.h"

class CreateHandler: public TransactionHandler{
  
 public:
  //This handles the admin action of creating an account in which the admin account specifies the account holder name and initial amount of the new account. A transaction is then created and added to session_transactions.
  void static handle(SessionStatus current_status, 
		     AccountsDatabase account_database,
		     std::vector<Transaction> &session_transactions);
};

#endif
